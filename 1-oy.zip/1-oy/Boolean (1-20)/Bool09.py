a=int(input())
b=int(input())
print(a<0 and b<0)