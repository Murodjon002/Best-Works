a=int(input())
b=int(input())
print(a%2==0 and b%2==0)