a=int(input())
print(a>=10 and a<=99)