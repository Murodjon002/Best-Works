a=int(input())
print(a<0)