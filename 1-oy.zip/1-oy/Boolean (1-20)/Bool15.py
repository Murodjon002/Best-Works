a=int(input())
x=a//10
y=a%10
print((x+y)%2==0)