b=int(input())
print(b%2==0)