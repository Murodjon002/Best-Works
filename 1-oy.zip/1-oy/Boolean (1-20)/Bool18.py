a=int(input())
print(a>10000 and a<99999)