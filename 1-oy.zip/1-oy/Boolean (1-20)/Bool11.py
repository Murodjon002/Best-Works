a=int(input())
b=int(input())
print(a%2==1 or b%2==1)