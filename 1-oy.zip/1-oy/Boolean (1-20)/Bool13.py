a=int(input())
print(a>=100 and a<=999)