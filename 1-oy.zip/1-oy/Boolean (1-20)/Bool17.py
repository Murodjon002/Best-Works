a=int(input())
x=a//100
y=a//10%10
z=a%10
print((x+y+z)%2==1)