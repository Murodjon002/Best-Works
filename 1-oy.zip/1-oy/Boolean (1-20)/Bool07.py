a=int(input())
b=int(input())
c=int(input())
print((a>b and b>c) or (c>b and b>a))