a=int(input())
print(a%2==1)