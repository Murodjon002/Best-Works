fist_name=input()
last_name=input()
print(f'My full name is {fist_name} {last_name}')