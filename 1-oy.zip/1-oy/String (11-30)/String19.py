a=input()
print(a.isalpha())