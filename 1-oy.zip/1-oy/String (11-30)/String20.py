a=input()
print(a.isupper())