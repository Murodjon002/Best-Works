a=input()
print(a.rstrip())