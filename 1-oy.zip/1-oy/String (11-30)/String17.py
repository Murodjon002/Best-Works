a=input()
n=int(input())
print((a+a[-1]*(n-1)))