a=input()
print(a.capitalize())