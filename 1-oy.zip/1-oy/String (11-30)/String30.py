first_name=input()
last_name=input()
full_name=first_name.capitalize()+' '+last_name.capitalize()
print(f'Hello {full_name}, how are you?')