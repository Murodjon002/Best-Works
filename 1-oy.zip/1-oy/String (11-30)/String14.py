a=input()
print(a.islower())