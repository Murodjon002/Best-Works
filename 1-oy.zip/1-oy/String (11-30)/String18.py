a=input()
print(a.isdigit())