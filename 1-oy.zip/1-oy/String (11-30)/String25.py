a=input()
print(a.endswith('n'))