a=input()
print(a.strip())