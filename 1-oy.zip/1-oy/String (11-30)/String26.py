a=input()
print(a.index("'"))