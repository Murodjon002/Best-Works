my_name=input()
print(f'My name is: {my_name}')