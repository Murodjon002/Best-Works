a=input()
print(a.lstrip())