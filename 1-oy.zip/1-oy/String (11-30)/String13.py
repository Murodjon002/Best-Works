a=input()
print(a.lower())