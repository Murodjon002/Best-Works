a=input()
print(a.title())