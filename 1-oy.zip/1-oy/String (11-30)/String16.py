a=input()
print('\t'+a.capitalize())