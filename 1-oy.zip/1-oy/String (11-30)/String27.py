a=input()
print(a.isspace())