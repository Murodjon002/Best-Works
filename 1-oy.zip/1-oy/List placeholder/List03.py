def func(n):
    a=[]
    for i in range(n):
        a.append(0)
    return a
print(func(int(input())))