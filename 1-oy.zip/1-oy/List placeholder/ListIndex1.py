def func(L1):
    first_iteam=L1[0]
    return first_iteam
p=(func(input().split(",")))
print(int(p))

