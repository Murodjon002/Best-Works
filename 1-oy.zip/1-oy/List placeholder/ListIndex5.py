def func(n):
    return n[:3]
print(func(input().split(",")))