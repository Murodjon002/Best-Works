def fuc(n):
    a=[]
    for i in range(-1,-n-1,-1):
        a.append(i)
    return a
print(fuc(int(input())))