def func():
    a=[]
    return type(a)
print(func())