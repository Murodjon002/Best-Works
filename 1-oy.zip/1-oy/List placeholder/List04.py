def func(n):
    a=[]
    for i in range(n):
        a.append(1)
    return a
print(func(int(input())))