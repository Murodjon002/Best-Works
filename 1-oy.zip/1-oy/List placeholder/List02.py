def func():
    a=[]
    return a
print(func())