def add_list(a):
    b=[]
    b.append(a[0])
    return b
print(add_list(input()))