def func_letters(letters):
    letter=[]
    letter.append(letters[1])
    letter.append(letters[2])
    letter.append(letters[3])

    
    return letter
print(func_letters('abcdefgi'))