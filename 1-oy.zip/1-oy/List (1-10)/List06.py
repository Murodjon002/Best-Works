def list_index(a_5,i):
    return int(a_5[i])
print(list_index(input(),int(input())))