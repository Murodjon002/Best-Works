def chack_list(lst):
    
    return lst==(len(lst)*lst[0])

print(chack_list(input()))