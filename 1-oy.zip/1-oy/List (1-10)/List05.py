def last_item(a_4):
    return int(a_4[-1])
print(last_item(input()))