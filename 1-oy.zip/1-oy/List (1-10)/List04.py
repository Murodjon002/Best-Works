def length_list(a):

    return len(a)
print(length_list(input()))