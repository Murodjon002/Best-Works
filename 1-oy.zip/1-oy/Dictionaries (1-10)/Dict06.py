def func_new_digit(digit):
    new_digit={4:'four',
    3:'three',
    5:'five'}
    return new_digit
a=func_new_digit([4,3,5])
print(a)