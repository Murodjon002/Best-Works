def func_add_colors(colors):
    colors={
    '1':'red',
    '2':'blue',
    '3':'yellow',
    '4':'green'}
    
    return colors

a=func_add_colors({})
print(a)