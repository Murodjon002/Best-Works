def func_add_city(city):
    city={
    '1':'Toshkent',
    '2':'Samarqand',
    '3':'Buxoro',
    '4':'Andijon'
    }
    return city
a=func_add_city({})
print((a))
