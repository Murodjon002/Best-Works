def func_add_two_items(cars):
    cars={'1':'BMW',
    '2':'Tesla',
    '3':'Chevrolet',
    '4':'Malibu'
    }
    cars['5'] ='Matiz'
    cars['6']='Nexia'
    return cars
a=func_add_two_items({})
print(a)



