def func_add_myself(myself):
    myself={'First_name': 'Murodjon',
    'Last_name': 'Abdinabiyev',
    'Age': 19,
    'City': 'Qashqadaryo'}
    return myself
a=func_add_myself({})
print(a)