m=float(input())
print(round(m,2))