from math import cos
a=float(input())
x=cos(a)
print(x)