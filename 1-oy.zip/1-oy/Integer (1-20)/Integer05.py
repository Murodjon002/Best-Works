a=float(input())
b=float(input())
c=9*a*a*b-27*a*a*b*b+15*b*b
print(round(c,2))