from math import sin
a=float(input())
x=sin(a)
print(x)