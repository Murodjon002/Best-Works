n=int(input())
s=(pow((3+n)/2,2))
print(s)