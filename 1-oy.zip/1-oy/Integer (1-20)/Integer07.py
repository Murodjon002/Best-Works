from math import pow,sqrt
x1=float(input())
y1=float(input())
x2=float(input())
y2=float(input())
sum=sqrt(pow(x2-x1,2)+pow(y2-y1,2))
print(round(sum,2))