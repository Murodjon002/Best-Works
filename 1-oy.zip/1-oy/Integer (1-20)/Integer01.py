from math import pi,sin,degrees
x=90
print(sin(x))