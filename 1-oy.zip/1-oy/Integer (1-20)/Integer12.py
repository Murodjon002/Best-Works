n=int(input())
s=2*pow(n+3,2)
print(s)