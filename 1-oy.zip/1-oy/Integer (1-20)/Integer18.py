x=int(input())
y=int(input())
s=6*pow(x,3)*pow(y,5)+4*pow(x,4)*pow(y,3)-24*x*y
print(s)