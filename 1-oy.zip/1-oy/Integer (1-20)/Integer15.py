a=int(input())
print(abs(a))