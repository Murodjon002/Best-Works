n=int(input())
x=int(input())
s=pow(n,x)+pow(6,x)
print(s)