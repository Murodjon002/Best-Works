a=int(input())
x=a%10
y=a//10%10
z=a//100
print(x*100+y*10+z)