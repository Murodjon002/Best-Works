a=int(input())
x=a%10
y=a//10%10
z=a//100
print(y*100+z*10+x)