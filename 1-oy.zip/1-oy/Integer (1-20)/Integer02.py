from math import pow,sqrt
a=int(input())
b=int(input())
print(pow(1/6*sqrt(a)+1/3*sqrt(b),2))