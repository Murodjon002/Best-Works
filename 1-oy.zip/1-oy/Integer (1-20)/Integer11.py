a=int(input())
x=a//10
y=a%10
print(x+y,x*y)