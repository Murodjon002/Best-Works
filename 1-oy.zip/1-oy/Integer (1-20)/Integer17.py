x=int(input())
y=int(input())
s=pow(x,4)+5*pow(x,2)+pow(x,3)*y
print(s)