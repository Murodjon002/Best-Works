f=open("txt_file/data02.txt").read()
print(len(f))