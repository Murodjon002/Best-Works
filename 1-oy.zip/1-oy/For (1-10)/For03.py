def func_list(K,N):
    list1=[]
    for i in range(N):
        list1.append(K)
    return list1
print(func_list(int(input()),int(input())))