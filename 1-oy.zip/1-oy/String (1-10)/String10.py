a=input()
b=input()
print(len(a)==len(b))