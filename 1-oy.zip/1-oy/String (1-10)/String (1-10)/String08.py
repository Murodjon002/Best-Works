a=input()
print(int(a)+8)