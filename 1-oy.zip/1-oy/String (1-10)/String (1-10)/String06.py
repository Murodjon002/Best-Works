a=input()
son=0
x=a[0]
y=a[1]
z=a[2]
e=a[3]
f=a[4]
if x==str(0):
    son+=1
if x==str(1):
    son+=1
if x==str(2):
    son+=1
if x==str(3):
    son+=1
if x==str(4):
    son+=1
if x==str(5):
    son+=1
if x==str(6):
    son+=1
if x==str(7):
    son+=1
if x==str(8):
    son+=1
if x==str(9):
    son+=1
    
if y==str(0):
    son+=1
if y==str(1):
    son+=1
if y==str(2):
    son+=1
if y==str(3):
    son+=1
if y==str(4):
    son+=1
if y==str(5):
    son+=1
if y==str(6):
    son+=1
if y==str(7):
    son+=1
if y==str(8):
    son+=1
if y==str(9):
    son+=1

if z==str(0):
    son+=1
if z==str(1):
    son+=1
if z==str(2):
    son+=1
if z==str(3):
    son+=1
if z==str(4):
    son+=1
if z==str(5):
    son+=1
if z==str(6):
    son+=1
if z==str(7):
    son+=1
if z==str(8):
    son+=1
if z==str(9):
    son+=1

if e==str(0):
    son+=1
if e==str(1):
    son+=1
if e==str(2):
    son+=1
if e==str(3):
    son+=1
if e==str(4):
    son+=1
if e==str(5):
    son+=1
if e==str(6):
    son+=1
if e==str(7):
    son+=1
if e==str(8):
    son+=1
if e==str(9):
    son+=1

if f==str(0):
    son+=1
if f==str(1):
    son+=1
if f==str(2):
    son+=1
if f==str(3):
    son+=1
if f==str(4):
    son+=1
if f==str(5):
    son+=1
if f==str(6):
    son+=1
if f==str(7):
    son+=1
if f==str(8):
    son+=1
if f==str(9):
    son+=1
print(son)


