a=input()
print(a[0:3])