a=input()
x=a[-1]
print(x)