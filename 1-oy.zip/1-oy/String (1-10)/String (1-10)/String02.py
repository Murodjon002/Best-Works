a=input()
x=len(a)
print(x%2==0)