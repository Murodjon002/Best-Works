a=input()
print(a[-2])