a=input()
print(a[1])