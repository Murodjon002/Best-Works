a=input()
count=0
ind=0
if a[ind]=="0" or a[ind]=="1" or a[ind]=="2" or a[ind]=="3" or a[ind]=="4" or a[ind]=="5" or a[ind]=="6" or a[ind]=="7" or a[ind]=="8" or a[ind]=="9":
    count+=1
ind+=1
if a[ind]=="0" or a[ind]=="1" or a[ind]=="2" or a[ind]=="3" or a[ind]=="4" or a[ind]=="5" or a[ind]=="6" or a[ind]=="7" or a[ind]=="8" or a[ind]=="9":
    count+=1
ind+=1
if a[ind]=="0" or a[ind]=="1" or a[ind]=="2" or a[ind]=="3" or a[ind]=="4" or a[ind]=="5" or a[ind]=="6" or a[ind]=="7" or a[ind]=="8" or a[ind]=="9":
    count+=1
ind+=1
if a[ind]=="0" or a[ind]=="1" or a[ind]=="2" or a[ind]=="3" or a[ind]=="4" or a[ind]=="5" or a[ind]=="6" or a[ind]=="7" or a[ind]=="8" or a[ind]=="9":
    count+=1
ind+=1
if a[ind]=="0" or a[ind]=="1" or a[ind]=="2" or a[ind]=="3" or a[ind]=="4" or a[ind]=="5" or a[ind]=="6" or a[ind]=="7" or a[ind]=="8" or a[ind]=="9":
    count+=1
ind+=1
print(count)
