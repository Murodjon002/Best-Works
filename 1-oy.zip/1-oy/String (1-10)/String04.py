a=input()
print(a[0]+a[1]+a[2])