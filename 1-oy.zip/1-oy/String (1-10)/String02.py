a=input()
print(len(a)%2==0)