x=float(input())
if x>=2:
    print(4)
elif x<=0:
    print(-x)
else:
    print(x*x)