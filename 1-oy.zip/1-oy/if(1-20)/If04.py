x=int(input())
y=int(input())
if x>0 and y>0:
    print("I - chorak")
elif x<0 and y>0:
    print("II -  chorak")
elif x<0 and y<0:
    print("III - chorak")
elif x>0 and y<0:
    print("IV - chorak")