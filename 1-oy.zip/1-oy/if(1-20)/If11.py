a=int(input())
result = ""
if a>=10 and a<=99:
    result+="ikki xonali "
else: 
    result+="uch xonali "
if a%2==0:
    result+="juft son"
else:
    result+="toq son"
print(result)
