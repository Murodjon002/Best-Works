a=int(input())
b=int(input())
if a>=20 and b==1:
    print(True)
else:
    print(False)