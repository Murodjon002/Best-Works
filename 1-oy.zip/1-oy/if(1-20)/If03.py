a=int(input())
b=int(input())
if a!=b:
    if a>b:
        print(a)
    else:
        print(b)
else:
    print(0)