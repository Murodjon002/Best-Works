x=float(input())
if x<-2 or x>2:
    print(2*x)
else:
    print(-3*x)