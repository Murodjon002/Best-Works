a=int(input())
if a>=1 and a<=9:
    print(1)
elif a>=10 and a<=99:
    print(2)
elif a>=100 and a<=999:
    print(3)
elif a>=1000 and a<=9999:
    print(4)