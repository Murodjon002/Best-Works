from math import sin
x=float(input())
if x<=0:
    print(x-6)
else:
    print(2*sin(x))