a=int(input())
b=int(input())
c=int(input())
m=a
if b<m:
    m=b
if c<m:
    m=c
print(m)
