a=int(input())
x=a//10
y=a%10
b=y*10+x
print(b>=a)