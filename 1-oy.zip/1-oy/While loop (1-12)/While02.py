n=int(input())
k=1
sum=0
while n>k:
    sum+=k
    k+=2
print(sum)
