n=int(input())
x=str(n)[::-2]
print(int(x))