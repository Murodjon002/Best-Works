n=int(input())
k=0
list1=[]
while n>k:
    list1.append(n-1)
    n-=1
print(list1)