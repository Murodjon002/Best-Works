n=int(input())
k=0
list1=[]
while k<n:
    list1.append(k)
    k+=1
print(list1)