n=int(input())
k=0
sum=0
while n>k:
    sum+=k
    k+=1
print(sum)
